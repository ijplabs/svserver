@echo off
title Junimo Mod Security - Trust Publisher Certificate
echo ========================================================
echo Memasang Sertifikat Keamanan Junimo Dedicated Server
echo ========================================================
cd /d "%~dp0"
certutil -user -addstore "TrustedPublisher" "JunimoSecurityCert.cer"
if %ERRORLEVEL% EQU 0 (
    echo.
    echo [SUKSES] Sertifikat berhasil ditambahkan ke Trusted Publishers Windows!
    echo Mod JunimoClientSync kini terverifikasi dan aman dari peringatan SmartScreen.
) else (
    echo.
    echo [GAGAL] Terjadi kesalahan saat mendaftarkan sertifikat.
)
pause
