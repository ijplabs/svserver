========================================================================
JUNIMO CLIENT SYNC - MOD KLIEN DENGAN SERTIFIKAT DIGITAL RESMI
========================================================================

Mod ini adalah mod resmi pendamping untuk Junimo Dedicated Server Stardew Valley.
File binary DLL ini telah ditandatangani secara digital (Authenticode Code Signing SHA-256)
dengan otoritas keamanan: "Junimo Dedicated Server Security Authority".

CARA VERIFIKASI KEASLIAN & KEAMANAN:
1. Klik kanan pada file "JunimoClientSync.dll" -> pilih "Properties" (Properti).
2. Buka tab "Digital Signatures" (Tanda Tangan Digital).
3. Anda akan melihat nama penandatangan resmi:
   "Junimo Dedicated Server Security Authority"
   dengan algoritma digest SHA-256.

AGAR WINDOWS SMART SCREEN TIDAK MENAMPILKAN PERINGATAN:
- Klik 2x file "Install-Certificate.bat" untuk mendaftarkan sertifikat publik ini
  ke daftar "Trusted Publishers" (Penerbit Tepercaya) Windows akun Anda.

CARA PEMASANGAN MOD:
- Letakkan seluruh folder "JunimoClientSync" ini ke dalam folder "Mods" Stardew Valley Anda.
- Jalankan game via StardewModdingAPI (SMAPI).
- Di menu utama atau Co-op Lobby, klik tombol "Sync Server Mods".
========================================================================
